//#include <QCoreApplication>
#include <QApplication>
#include "thread8.h"

int main(int argc, char *argv[])
{
    //QCoreApplication a(argc, argv);
    QApplication a(argc, argv);

    qRegisterMetaType<TextAndNumber>("TextAndNumber");

    TextDevice device;
    TextThread foo("Foo"), bar("Bar");

    QObject::connect(&foo, SIGNAL(writeText(TextAndNumber)), &device, SLOT(write(TextAndNumber)));
    QObject::connect(&bar, SIGNAL(writeText(TextAndNumber)), &device, SLOT(write(TextAndNumber)));

     foo.start();
     bar.start();
     device.start();

     QMessageBox::information(0,"Threading", "Close me to Stop!");

     foo.stop();
     bar.stop();
     device.stop();

     foo.wait();
     bar.wait();
     device.wait();

    return a.exec();
}
