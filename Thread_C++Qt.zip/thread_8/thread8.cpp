#include "thread8.h"

thread8::thread8()
{

}

TextAndNumber::TextAndNumber()
{

}

TextAndNumber::TextAndNumber(int i, QString txt)
{
    number = i;
    text = txt;
}

TextThread::TextThread(const QString &text)
{
m_text = text;
m_stop = false;
m_count_tt = 0;
}

void TextThread::run()
{

    while (!m_stop) {
       emit writeText(TextAndNumber(m_count_tt++, m_text));
        sleep(1);
    }
}

void TextThread::stop()
{
    m_stop = true;
}

TextDevice::TextDevice()
{
    m_count = 0;
}

void TextDevice::run()
{
    exec();
}

void TextDevice::stop()
{
   quit();
}

void TextDevice::write(TextAndNumber tan)
{
    QMutexLocker locker(&m_mutex);

    qDebug()<<QString("Call %1 (%3): %2").arg(m_count++).arg(tan.text).arg(tan.number);
}
