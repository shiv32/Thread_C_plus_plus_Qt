/*
                     Program-8

Author:    Shiv Kumar
Subject:   Sending Your Own Types Between Threads
Reference: Foundations of Qt Development by Johan Thelin
*/
#ifndef THREAD8_H
#define THREAD8_H

#include<QObject>
#include<QThread>
#include<QMutex>
#include<QMessageBox>
#include<QDebug>


class thread8
{
public:
    thread8();
};

class TextAndNumber
{
public:
    TextAndNumber();
    TextAndNumber(int, QString);
    int number;
    QString text;
};

class TextThread : public QThread
{
Q_OBJECT

public:
TextThread(const QString &text);
void run();
void stop();

signals:
void writeText(TextAndNumber);

private:
QString m_text;
bool m_stop;
int m_count_tt;
};


class TextDevice : public QThread
{
 Q_OBJECT

public:
TextDevice();
void run();
void stop();

public slots:
void write(TextAndNumber);

private:
int m_count;
QMutex m_mutex;
};

#endif // THREAD8_H
