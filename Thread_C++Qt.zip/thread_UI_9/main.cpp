#include "dialog.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Dialog w;
    w.show();

    TextThread foo("Foo"), bar("Bar");

    qRegisterMetaType<TextAndNumber>("TextAndNumber");

    QObject::connect(&foo, SIGNAL(writeText(TextAndNumber)), &w, SLOT(showText(TextAndNumber)) );
    QObject::connect(&bar, SIGNAL(writeText(TextAndNumber)), &w, SLOT(showText(TextAndNumber)) );

    foo.start();
    bar.start();



    return a.exec();
}
