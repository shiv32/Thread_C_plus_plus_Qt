/*
                     Program-9

Author:    Shiv Kumar
Subject:   The User Interface Thread
Reference: Foundations of Qt Development by Johan Thelin
*/
#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>

#include<QDialogButtonBox>
#include<QThread>
#include<QMutex>
#include<QDebug>
#include<QMetaType>


namespace Ui {
class Dialog;
}

class TextAndNumber
{
public:
    TextAndNumber();
    TextAndNumber(int, QString);
    int number;
    QString text;
};


class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = 0);
    ~Dialog();

public slots:
void showText(TextAndNumber tan);

private slots:
    void on_buttonBox_clicked(QAbstractButton *button);

private:
    Ui::Dialog *ui;
    int count;
    QMutex mutex;
};

class TextThread : public QThread
{
Q_OBJECT

public:
    TextThread(const QString &text);
    void run();

signals:
void writeText(TextAndNumber);

private:
QString m_text;
bool m_stop;
};

#endif // DIALOG_H
