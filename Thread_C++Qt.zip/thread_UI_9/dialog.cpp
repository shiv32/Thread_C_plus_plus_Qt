#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);

    setWindowTitle("Threading Demostration");

    connect(ui->buttonBox, SIGNAL(clicked(QAbstractButton*)),this, SLOT(on_buttonBox_clicked(QAbstractButton*)));

    count = 0;
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::showText(TextAndNumber tan)
{
    QMutexLocker locker(&mutex);
    ui->listWidget->addItem(QString("Call %1 (%3): %2").arg(count++).arg(tan.text).arg(tan.number));
}

void Dialog::on_buttonBox_clicked(QAbstractButton *button)
{
    if(ui->buttonBox->buttonRole(button) == QDialogButtonBox::ResetRole)
        ui->listWidget->clear();

    if(ui->buttonBox->buttonRole(button) == QDialogButtonBox::RejectRole)
        qApp->exit();
}

TextAndNumber::TextAndNumber()
{

}

TextAndNumber::TextAndNumber(int i, QString str)
{
    number = i;
    text = str;
}

TextThread::TextThread(const QString &text)
{
 m_text = text;
m_stop = false;
}

void TextThread::run()
{
    int m_count = 0;

    while(!m_stop)
    {
        emit writeText(TextAndNumber(m_count++, m_text));
        sleep(1);
    }
}
