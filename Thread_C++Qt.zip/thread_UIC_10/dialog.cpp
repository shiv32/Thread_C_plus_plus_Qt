#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);

    setWindowTitle(tr("Process Demonstration"));
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_uicButton_clicked()
{
    QTimer::singleShot(1000,this, SLOT(runUic()));
}

void Dialog::runUic()
{
    ui->uicButton->setEnabled(false);
    ui->textEdit->setText(" ");

    process = new QProcess(this);

    connect(process, SIGNAL(error(QProcess::ProcessError)), this, SLOT(handleError(QProcess::ProcessError)));
    connect(process, SIGNAL(finished(int,QProcess::ExitStatus)), this, SLOT(handleFinish(int,QProcess::ExitStatus)));
    connect(process, SIGNAL(readyReadStandardError()), this, SLOT(handleReadStandardError()));
    connect(process, SIGNAL(readyReadStandardOutput()), this, SLOT(handleReadStandardOutput()));
    connect(process, SIGNAL(started()), this, SLOT(handlestarted()));
    connect(process, SIGNAL(stateChanged(QProcess::ProcessState)), this, SLOT(handleStateChange(QProcess::ProcessState)));

    QStringList arguments;
    arguments << "-tr" << "MYTR" << "dialog.ui";

    process->start("uic", arguments);

}

void Dialog::handleError(QProcess::ProcessError err)
{

    QString errText;

    switch (err) {
    case QProcess::FailedToStart:
        errText = "Failed To Start";
        break;
    }

    ui->textEdit->append("<b>"+errText+"</b>");
}

void Dialog::handleFinish(int code, QProcess::ExitStatus status)
{
    QString statusText;

    switch (status) {
    case QProcess::NormalExit:
        statusText = "NormalExit";
        break;
    case QProcess::CrashExit:
        statusText = "CrashExit";
        break;
    }

    ui->textEdit->append(QString("<p><b>%1 (%2)</b></p>").arg(statusText).arg(code));
}

void Dialog::handleReadStandardError()
{
    ui->textEdit->append(process->readAllStandardError());

}

void Dialog::handleReadStandardOutput()
{
    ui->textEdit->append(process->readAllStandardOutput());
}

void Dialog::handlestarted()
{
    ui->textEdit->append("<b>Started</b>");
}

void Dialog::handleStateChange(QProcess::ProcessState status)
{
    QString statusText;

    switch (status) {
    case QProcess::NotRunning:
        statusText = "Not Running";
        break;
    case QProcess::Starting:
        statusText = "Starting";
        break;
    }

    ui->textEdit->append(QString("<p>New status: <b>%1</b></p>").arg(statusText));
}
