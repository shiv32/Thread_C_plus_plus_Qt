#include "thread7.h"

thread7::thread7()
{

}

TextThread::TextThread(const QString & text)
{
    m_text = text;
    m_stop = false;

}

void TextThread::run()
{
    while (!m_stop) {
        emit writeText(m_text);
        sleep(1);
    }
}

void TextThread::stop()
{
    m_stop = true;

}

TextDevice::TextDevice()
{
    m_count = 0;
}

void TextDevice::run()
{
    exec();
}

void TextDevice::stop()
{
    quit();
}

void TextDevice::write(const QString &text)
{
    QMutexLocker locker(&m_mutex);
    qDebug()<<QString("Call %1: %2").arg(m_count++).arg(text);

}
