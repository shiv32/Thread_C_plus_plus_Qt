/*
                     Program-7

Author:    Shiv Kumar
Subject:   passing strings b/w threads using signal-slot
Reference: Foundations of Qt Development by Johan Thelin
*/
#ifndef THREAD7_H
#define THREAD7_H

#include<QObject>
#include<QThread>
#include<QMutex>
#include<QDebug>
#include<QMessageBox>


class thread7
{
public:
    thread7();
};

class TextThread : public QThread
{
 Q_OBJECT
public:
    TextThread(const QString &);
    void run();
    void stop();
signals:
void writeText(const QString &);

private:
QString m_text;
bool m_stop;

};

class TextDevice : public QThread
{
Q_OBJECT

public:
TextDevice();
void run();
void stop();

public slots:
void write(const QString &text);

private:
int m_count;
QMutex m_mutex;
};


#endif // THREAD7_H
