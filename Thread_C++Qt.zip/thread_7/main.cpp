//#include <QCoreApplication>
#include <QApplication>
#include "thread7.h"

int main(int argc, char *argv[])
{
//    QCoreApplication a(argc, argv);
    QApplication a(argc, argv);

    TextDevice device;

    TextThread foo("Foo"), bar("Bar");

    QObject::connect(&foo, SIGNAL(writeText(const QString&)), &device, SLOT(write(const QString&)));
    QObject::connect(&bar, SIGNAL(writeText(const QString&)), &device, SLOT(write(const QString&)));

     foo.start();
     bar.start();
     device.start();

     QMessageBox::information(NULL, "Threading","Close me to stop!");

     foo.stop();
     bar.stop();
     device.stop();

     foo.wait();
     bar.wait();
     device.wait();

    return a.exec();
}
