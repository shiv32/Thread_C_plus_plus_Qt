/*
                     Program-5

Author:    Shiv Kumar
Subject:   Passing Data Through a Shared Circular Buffer.
           one producer and one consumer
Reference: Foundations of Qt Development by Johan Thelin
*/

#ifndef THREADSEMAPHORE5_H
#define THREADSEMAPHORE5_H

#include<QThread>
#include<QDebug>
#include<QSemaphore>

class threadsemaphore5
{
public:
    threadsemaphore5();
};

//consumer
class TextConsumer : public QThread
{

public:
    void run();

};

//producer
class TextProducer : public QThread
{
public:
    TextProducer(const QString &text);
    void run();
private:
    QString m_text;

};


#endif // THREADSEMAPHORE5_H
