#include <QCoreApplication>
#include "threadsemaphore5.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    TextProducer producer("shiv kumar");
    TextConsumer consumer;

    producer.start();
    consumer.start();


    producer.wait();
    consumer.wait();

    return a.exec();
}
