#include "threadsemaphore5.h"

const int bufferSize = 1;
QChar buffer[bufferSize];
QSemaphore freeSpcae(bufferSize);
QSemaphore availableData(0);
bool atEnd = false;


threadsemaphore5::threadsemaphore5()
{

}

void TextConsumer::run()
{
    int i =0;

    while (!atEnd || availableData.available()) {
        availableData.acquire();

        qDebug()<<buffer[i];

        i = (i+1) % bufferSize;

        freeSpcae.release();
    }
}

TextProducer::TextProducer(const QString &text)
{
    m_text = text;
}

void TextProducer::run()
{
  for(int i = 0; i<m_text.length(); ++i){

      freeSpcae.acquire();

      buffer[i%bufferSize] = m_text[i];

      if(i == m_text.length()-1){ //end of string
          atEnd = true;
      }
   availableData.release();
  }
}


