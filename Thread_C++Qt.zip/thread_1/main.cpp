//#include <QCoreApplication>
#include <QApplication>
#include "thread1.h"

int main(int argc, char *argv[])
{
//    QCoreApplication a(argc, argv);
    QApplication a(argc, argv);

    Textthread foo("foo"), bar("bar");

    foo.start();
    bar.start();

    QMessageBox::information(0,"Threading","Close me to stop !");

    stopthread = true;

    foo.wait();
    bar.wait();


    return a.exec();
}
