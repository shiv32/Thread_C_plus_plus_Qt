/*
                     Program-1

Author:    Shiv Kumar
Subject:   Building a Simple Threading Application
Reference: Foundations of Qt Development by Johan Thelin
*/

#ifndef THREAD1_H
#define THREAD1_H

#include<QThread>
#include<QDebug>
#include<QMessageBox>

extern bool stopthread;

class thread1
{
public:
    thread1();
};

//thread
class Textthread : public QThread
{
public:
    Textthread(const QString &text);
    void run();

private:
QString m_text;
};

#endif // THREAD1_H
