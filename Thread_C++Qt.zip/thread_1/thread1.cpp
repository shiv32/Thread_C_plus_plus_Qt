#include "thread1.h"

bool stopthread = false;

thread1::thread1()
{

}

Textthread::Textthread(const QString &text)
{
    m_text = text;
}

void Textthread::run()
{
    while (!stopthread) {
        qDebug()<<m_text;
        sleep(1);
    }

}
