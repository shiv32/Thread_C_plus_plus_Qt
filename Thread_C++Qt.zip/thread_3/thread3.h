/*
                     Program-3

Author:    Shiv Kumar
Subject:   Locking for Reading and Writing by thread
Reference: Foundations of Qt Development by Johan Thelin
*/

#ifndef THREAD3_H
#define THREAD3_H

#include<QThread>
#include<QReadWriteLock>
#include<QDebug>
#include<QMessageBox>

extern bool stopThread;

class thread3
{
public:
    thread3();
};

class TextDevice
{
public:
    TextDevice();
    void increase();
    void write(const QString &);
private:
    int count;
    QReadWriteLock lock;
};

class IncreaseThread : public QThread
{
public:
    IncreaseThread(TextDevice *device);
    void run();
private:
TextDevice *m_device;
};

class TextThread : public QThread
{
public:
    TextThread(const QString &text, TextDevice *device);
    void run();

private:
QString m_text;
TextDevice *m_device;

};

#endif // THREAD3_H
