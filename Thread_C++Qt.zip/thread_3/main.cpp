//#include <QCoreApplication>
#include <QApplication>
#include "thread3.h"

int main(int argc, char *argv[])
{
//    QCoreApplication a(argc, argv);
    QApplication a(argc, argv);

    TextDevice device;
    IncreaseThread inc(&device);

    TextThread foo("Foo", &device), bar("Bar", &device);

    inc.start();
    foo.start();
    bar.start();
    inc.start();

    QMessageBox::information(0, "Threading","Close me to stop !");
     stopThread = 1;

    foo.wait();
    bar.wait();
    inc.wait();


    return a.exec();
}
