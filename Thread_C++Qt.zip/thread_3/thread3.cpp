#include "thread3.h"

bool stopThread =0;

thread3::thread3()
{

}

TextDevice::TextDevice()
{
    count = 0;
}

void TextDevice::increase()
{
    QWriteLocker locker(&lock);
    count++;
}

void TextDevice::write(const QString & text)
{
    QReadLocker locker(&lock);
    qDebug()<<QString("call %1: %2").arg(count).arg(text);
}

IncreaseThread::IncreaseThread(TextDevice *device)
{
    m_device = device;
}

void IncreaseThread::run()
{
    while (!stopThread) {
        msleep(1200);
        m_device->increase();
    }

}

TextThread::TextThread(const QString &text, TextDevice *device)
{
    m_text = text;
    m_device = device;
}

void TextThread::run()
{
    while(!stopThread){
        m_device->write(m_text);
        sleep(1);
    }
}
