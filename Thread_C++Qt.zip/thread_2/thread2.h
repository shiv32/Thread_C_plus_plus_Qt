/*
                             Program-2
Author:    Shiv Kumar
Subject:   protected counting using thread
Reference: Foundations of Qt Development by Johan Thelin
*/
#ifndef THREAD2_H
#define THREAD2_H

#include<QThread>
#include<QDebug>
#include<QMessageBox>
#include<QMutex>
#include<QMutexLocker>

extern bool stopThread;

class thread2
{
public:
    thread2();
};

class TextDevice
 {
  public:
    TextDevice();
    void write(const QString&);
 private:
    int count;
    QMutex mutex;

 };

class textThread : public QThread
{
public:
    textThread(const QString &str, TextDevice *ob);
    void run();
private:
QString m_text;
TextDevice *m_device;

};

#endif // THREAD2_H
