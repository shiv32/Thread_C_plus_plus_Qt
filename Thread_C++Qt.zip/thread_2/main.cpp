//#include <QCoreApplication>
#include <QApplication>
#include "thread2.h"


int main(int argc, char *argv[])
{
   // QCoreApplication a(argc, argv);
    QApplication a(argc, argv);


    TextDevice device;

    textThread foo("foo", &device), bar("bar", &device);

    foo.start();
    bar.start();

    QMessageBox::information(0,"Threading","Close me to stop !");

    stopThread = true;

    foo.wait();
    bar.wait();


    return a.exec();
}
