#include "thread2.h"

bool stopThread = false;

thread2::thread2()
{

}

TextDevice::TextDevice()
{
    count = 0;
}

void TextDevice::write(const QString &text)
{
    QMutexLocker locker(&mutex);
    qDebug()<< QString("call %1: %2").arg(count++).arg(text);
}

textThread::textThread(const QString &str, TextDevice *ob)
{
    m_device = ob;
    m_text = str;
}

void textThread::run()
{
    while(!stopThread){

        m_device->write(m_text);
        sleep(1);
    }

}
