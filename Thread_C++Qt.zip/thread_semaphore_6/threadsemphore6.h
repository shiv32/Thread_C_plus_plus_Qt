/*
                     Program-6

Author:    Shiv Kumar
Subject:   Dealing with Competing Producers.
           two producer and one consumer
Reference: Foundations of Qt Development by Johan Thelin
*/
#ifndef THREADSEMPHORE6_H
#define THREADSEMPHORE6_H

#include<QThread>
#include<QDebug>
#include<QMutex>
#include<QSemaphore>


class threadsemphore6
{
public:
    threadsemphore6();
};


//thread consumer class
class TextConsumer : public QThread
{
public:
    void run();
};

//thread producer class
class TextProducer : public QThread
{
public:
    TextProducer(const QString &text);
    void run();
private:
    QString m_text;
};


#endif // THREADSEMPHORE6_H
