#include <QCoreApplication>
#include "threadsemphore6.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    TextProducer p1("shiv kumar shiv kumar");
    TextProducer p2("SHIV KUMAR SHIV KUMAR");

    TextConsumer consumer;

    p1.start();
    p2.start();
    consumer.start();

    p1.wait();
    p2.wait();
    consumer.wait();

    return a.exec();
}
