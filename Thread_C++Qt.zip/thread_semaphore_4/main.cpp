#include <QCoreApplication>
#include "threadsemaphore4.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    threadSemaphore4 obj;

    return a.exec();
}
