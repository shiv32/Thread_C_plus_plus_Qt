/*
                     Program-4

Author:    Shiv Kumar
Subject:   Sharing Resources Among Threads using semaphore
Reference: Foundations of Qt Development by Johan Thelin
*/
#ifndef THREADSEMAPHORE4_H
#define THREADSEMAPHORE4_H

#include<QSemaphore>
#include<QDebug>


class threadSemaphore4
{
public:
    threadSemaphore4();
};

#endif // THREADSEMAPHORE4_H
