#include "threadsemaphore4.h"

threadSemaphore4::threadSemaphore4()
{
    QSemaphore availableData(0);

    availableData.release(); //free 1
    availableData.release(5); // free 5

    qDebug()<<"Available Resources: "<<availableData.available(); // show 6

    availableData.acquire(2);

    qDebug()<<"Available Resources: "<<availableData.available(); // show 4

    availableData.tryAcquire(5); //get 0

    qDebug()<<"Available Resources: "<<availableData.available(); // show 4

    availableData.tryAcquire(4); // get 4

    qDebug()<<"Available Resources: "<<availableData.available(); // show 0





}
